#!/usr/bin/env python3
"""PGFlow local application: standard-library Python + SQLite + HTML/CSS/JS.
Run: PGFLOW_ADMIN_PASSWORD='strong password' python app.py
"""
import os, json, sqlite3, hashlib, hmac, secrets, mimetypes, re
from pathlib import Path
from http.server import ThreadingHTTPServer, BaseHTTPRequestHandler
from http.cookies import SimpleCookie
from urllib.parse import urlparse, unquote
from datetime import datetime, timedelta, timezone

ROOT=Path(__file__).resolve().parent
DB=ROOT/'pgflow.db'
UPLOADS=ROOT/'uploads'
ADMIN_EMAIL='princeguttreal@gmail.com'
MAX_BODY=1024*1024
MAX_UPLOAD=2*1024*1024*1024
ALLOWED_VIDEO={'.mp4','.mov','.webm','.m4v'}
def connect():
 c=sqlite3.connect(DB);c.row_factory=sqlite3.Row;return c
def hash_pw(p,s=None):
 s=s or secrets.token_hex(16)
 return s+':'+hashlib.pbkdf2_hmac('sha256',p.encode(),bytes.fromhex(s),350000).hex()
def verify_pw(p,stored):
 try:
  salt,digest=stored.split(':',1)
  return hmac.compare_digest(hash_pw(p,salt),stored)
 except Exception:return False
def setup():
 with connect() as c:
  c.executescript("""
  CREATE TABLE IF NOT EXISTS users(email TEXT PRIMARY KEY,password_hash TEXT NOT NULL,role TEXT NOT NULL);
  CREATE TABLE IF NOT EXISTS sessions(token_hash TEXT PRIMARY KEY,email TEXT NOT NULL,expires TEXT NOT NULL);
  CREATE TABLE IF NOT EXISTS brands(id INTEGER PRIMARY KEY,name TEXT UNIQUE NOT NULL);
  CREATE TABLE IF NOT EXISTS goals(id INTEGER PRIMARY KEY,brand_id INTEGER NOT NULL,metric TEXT NOT NULL,target INTEGER NOT NULL,UNIQUE(brand_id,metric));
  CREATE TABLE IF NOT EXISTS leads(id INTEGER PRIMARY KEY,brand_id INTEGER NOT NULL,name TEXT NOT NULL,origin TEXT NOT NULL,status TEXT NOT NULL DEFAULT 'Novo',created_at TEXT NOT NULL);
  CREATE TABLE IF NOT EXISTS drafts(id INTEGER PRIMARY KEY,brand_id INTEGER NOT NULL,platform TEXT NOT NULL,caption TEXT NOT NULL,title TEXT NOT NULL DEFAULT '',updated_at TEXT NOT NULL,UNIQUE(brand_id,platform));
  CREATE TABLE IF NOT EXISTS media(id INTEGER PRIMARY KEY,brand_id INTEGER NOT NULL,filename TEXT NOT NULL,bytes INTEGER NOT NULL,created_at TEXT NOT NULL);
  CREATE TABLE IF NOT EXISTS challenges(id INTEGER PRIMARY KEY,brand_id INTEGER NOT NULL,title TEXT NOT NULL,status TEXT NOT NULL DEFAULT 'active',created_at TEXT NOT NULL);
  """)
  for name in ['Dra. Fabi Veterinária','Estilo de Vet','Principado Produções']:
   c.execute('INSERT OR IGNORE INTO brands(name) VALUES (?)',(name,))
  password=os.getenv('PGFLOW_ADMIN_PASSWORD','')
  if password and len(password)>=12:
   c.execute('INSERT OR IGNORE INTO users(email,password_hash,role) VALUES(?,?,?)',(ADMIN_EMAIL,hash_pw(password),'superadmin'))
  elif not c.execute('SELECT 1 FROM users').fetchone():
   print('AVISO: nenhum usuário configurado. Defina PGFLOW_ADMIN_PASSWORD (mínimo 12 caracteres) e reinicie.')
def now():return datetime.now(timezone.utc).isoformat()
def read_json(handler):
 n=int(handler.headers.get('Content-Length','0'))
 if n>MAX_BODY or n<0:raise ValueError('Payload muito grande')
 return json.loads(handler.rfile.read(n) or b'{}')
class Handler(BaseHTTPRequestHandler):
 def headers(self,code=200,ctype='application/json; charset=utf-8',extra=None):
  self.send_response(code);self.send_header('Content-Type',ctype)
  self.send_header('X-Content-Type-Options','nosniff')
  self.send_header('X-Frame-Options','DENY')
  self.send_header('Referrer-Policy','same-origin')
  self.send_header('Cache-Control','no-store')
  self.send_header('Content-Security-Policy',"default-src 'self'; style-src 'self' 'unsafe-inline' https://fonts.googleapis.com; font-src 'self' https://fonts.gstatic.com; img-src 'self' data: blob:; media-src 'self' blob:; script-src 'self'; connect-src 'self'")
  for k,v in (extra or {}).items():self.send_header(k,v)
  self.end_headers()
 def send_json(self,obj,code=200,extra=None):
  self.headers(code,extra=extra);self.wfile.write(json.dumps(obj,ensure_ascii=False).encode())
 def current_user(self):
  ck=SimpleCookie()
  try:ck.load(self.headers.get('Cookie',''))
  except:return None
  if 'pg_session' not in ck:return None
  token=ck['pg_session'].value
  with connect() as c:
   row=c.execute('SELECT email,expires FROM sessions WHERE token_hash=?',(hashlib.sha256(token.encode()).hexdigest(),)).fetchone()
   if row and row['expires']>now():return row['email']
  return None
 def serve(self,path):
  if path=='/':path='/index.html'
  if path=='/index.html':file=ROOT/'templates/index.html'
  elif path.startswith('/static/'):
   rel=Path(unquote(path[1:]))
   file=(ROOT/rel).resolve()
   if not file.is_relative_to((ROOT/'static').resolve()):return self.send_json({'error':'Não autorizado'},403)
  else:return self.send_json({'error':'Não encontrado'},404)
  if not file.is_file():return self.send_json({'error':'Não encontrado'},404)
  ct=mimetypes.guess_type(file.name)[0] or 'application/octet-stream'
  if file.suffix=='.js':ct='application/javascript'
  if file.suffix in ('.html','.css','.js'):ct+='; charset=utf-8'
  self.headers(200,ct);self.wfile.write(file.read_bytes())
 def do_GET(self):
  path=urlparse(self.path).path
  if not path.startswith('/api/'):return self.serve(path)
  user=self.current_user()
  if path=='/api/me':return self.send_json({'authenticated':bool(user),'email':user,'role':'superadmin' if user else None})
  if not user:return self.send_json({'error':'Sessão necessária'},401)
  with connect() as c:
   if path=='/api/brands':return self.send_json({'brands':[dict(r) for r in c.execute('SELECT * FROM brands')]})
   if path=='/api/dashboard':
    return self.send_json({'leads':c.execute('SELECT count(*) FROM leads').fetchone()[0],
     'drafts':c.execute('SELECT count(*) FROM drafts').fetchone()[0],
     'videos':c.execute('SELECT count(*) FROM media').fetchone()[0],
     'challenges':c.execute("SELECT count(*) FROM challenges WHERE status='active'").fetchone()[0],
     'notice':'Dados reais locais; métricas das redes dependem de OAuth e APIs oficiais.'})
   if path=='/api/leads':return self.send_json({'leads':[dict(r) for r in c.execute('SELECT * FROM leads ORDER BY id DESC LIMIT 300')]})
   if path=='/api/goals':return self.send_json({'goals':[dict(r) for r in c.execute('SELECT * FROM goals')]})
   if path=='/api/drafts':return self.send_json({'drafts':[dict(r) for r in c.execute('SELECT * FROM drafts')]})
   if path=='/api/challenges':return self.send_json({'challenges':[dict(r) for r in c.execute('SELECT * FROM challenges ORDER BY id DESC')]})
  return self.send_json({'error':'Não encontrado'},404)
 def do_POST(self):
  path=urlparse(self.path).path
  if path=='/api/upload':return self.upload()
  try:data=read_json(self)
  except Exception:return self.send_json({'error':'JSON inválido ou grande demais'},400)
  if path=='/api/login':
   email=str(data.get('email','')).strip().lower();password=str(data.get('password',''))
   with connect() as c:row=c.execute('SELECT password_hash FROM users WHERE email=?',(email,)).fetchone()
   if not row or not verify_pw(password,row['password_hash']):return self.send_json({'error':'E-mail ou senha inválidos'},401)
   token=secrets.token_urlsafe(40)
   with connect() as c:c.execute('INSERT INTO sessions VALUES(?,?,?)',(hashlib.sha256(token.encode()).hexdigest(),email,(datetime.now(timezone.utc)+timedelta(hours=12)).isoformat()))
   return self.send_json({'ok':True,'email':email},extra={'Set-Cookie':f'pg_session={token}; HttpOnly; SameSite=Strict; Path=/; Max-Age=43200'})
  if path=='/api/logout':
   ck=SimpleCookie()
   try:ck.load(self.headers.get('Cookie',''))
   except:pass
   if 'pg_session' in ck:
    with connect() as c:c.execute('DELETE FROM sessions WHERE token_hash=?',(hashlib.sha256(ck['pg_session'].value.encode()).hexdigest(),))
   return self.send_json({'ok':True},extra={'Set-Cookie':'pg_session=; HttpOnly; SameSite=Strict; Path=/; Max-Age=0'})
  if not self.current_user():return self.send_json({'error':'Sessão necessária'},401)
  try:
   brand=int(data.get('brand_id',1))
   with connect() as c:
    if not c.execute('SELECT 1 FROM brands WHERE id=?',(brand,)).fetchone():return self.send_json({'error':'Marca inválida'},400)
    if path=='/api/leads':
     name=str(data.get('name','')).strip()[:120];origin=str(data.get('origin','')).strip()[:40]
     if not name or not origin:return self.send_json({'error':'Preencha nome e origem'},400)
     c.execute('INSERT INTO leads(brand_id,name,origin,created_at) VALUES(?,?,?,?)',(brand,name,origin,now()))
    elif path=='/api/goals':
     metric=str(data.get('metric','')).strip()[:60];target=int(data.get('target',0))
     if not metric or target<0 or target>1000000000:raise ValueError()
     c.execute('INSERT INTO goals(brand_id,metric,target) VALUES(?,?,?) ON CONFLICT(brand_id,metric) DO UPDATE SET target=excluded.target',(brand,metric,target))
    elif path=='/api/drafts':
     platform=str(data.get('platform',''));caption=str(data.get('caption',''));title=str(data.get('title',''))
     limits={'instagram':2200,'tiktok':4000,'youtube':5000}
     if platform not in limits or len(caption)>limits[platform] or len(title)>100:raise ValueError()
     c.execute("INSERT INTO drafts(brand_id,platform,caption,title,updated_at) VALUES(?,?,?,?,?) ON CONFLICT(brand_id,platform) DO UPDATE SET caption=excluded.caption,title=excluded.title,updated_at=excluded.updated_at",(brand,platform,caption,title,now()))
    elif path=='/api/challenges':
     title=str(data.get('title','')).strip()[:160]
     if not title:raise ValueError()
     c.execute('INSERT INTO challenges(brand_id,title,created_at) VALUES(?,?,?)',(brand,title,now()))
    else:return self.send_json({'error':'Não encontrado'},404)
   return self.send_json({'ok':True})
  except (ValueError,TypeError,OverflowError):return self.send_json({'error':'Dados inválidos'},400)
 def upload(self):
  if not self.current_user():return self.send_json({'error':'Sessão necessária'},401)
  try:
   n=int(self.headers.get('Content-Length','0'))
   brand=int(self.headers.get('X-Brand-ID','1'))
   name=self.headers.get('X-Filename','video.mp4')
   ext=Path(name).suffix.lower()
   if n<1 or n>MAX_UPLOAD or ext not in ALLOWED_VIDEO:return self.send_json({'error':'Arquivo inválido ou maior que 2 GB'},400)
   with connect() as c:
    if not c.execute('SELECT 1 FROM brands WHERE id=?',(brand,)).fetchone():return self.send_json({'error':'Marca inválida'},400)
   filename=secrets.token_hex(20)+ext;target=UPLOADS/filename
   remaining=n
   with target.open('wb') as f:
    while remaining:
     chunk=self.rfile.read(min(1024*1024,remaining))
     if not chunk:break
     f.write(chunk);remaining-=len(chunk)
   if remaining:target.unlink(missing_ok=True);return self.send_json({'error':'Upload incompleto'},400)
   with connect() as c:c.execute('INSERT INTO media(brand_id,filename,bytes,created_at) VALUES(?,?,?,?)',(brand,filename,n,now()))
   return self.send_json({'ok':True,'size':n,'note':'Original armazenado. Transcodificação e publicação ainda não conectadas.'})
  except Exception:return self.send_json({'error':'Falha no upload'},500)
if __name__=='__main__':
 setup()
 port=int(os.getenv('PORT','8000'))
 print(f'PGFlow disponível em http://127.0.0.1:{port}')
 ThreadingHTTPServer(('127.0.0.1',port),Handler).serve_forever()
