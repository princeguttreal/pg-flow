# PGFlow — Master Control

Aplicação local com **Python (biblioteca padrão), SQLite, HTML5, CSS3 e JavaScript**, sem dependências Python.

## Executar

Python 3.10+ recomendado. No terminal:

**Linux/macOS**
```bash
export PGFLOW_ADMIN_PASSWORD="escolha-uma-senha-forte-com-12-ou-mais-caracteres"
python3 app.py
```

**Windows PowerShell**
```powershell
$env:PGFLOW_ADMIN_PASSWORD="escolha-uma-senha-forte-com-12-ou-mais-caracteres"
python app.py
```

Abra **http://127.0.0.1:8000**. Entre com `princeguttreal@gmail.com` e a senha que você definiu na variável de ambiente.

A senha não está incluída nos arquivos. O banco `pgflow.db` é criado no primeiro início. Para trocar a senha depois da configuração inicial, implemente um fluxo de troca de senha seguro; alterar a variável de ambiente não substitui a senha armazenada.

## Funcionalidades que funcionam
- Login por senha mestre com hash PBKDF2 e sessão HttpOnly, logout
- Interface responsiva com animações, bolhas, navegação e dashboards
- Marcas predefinidas; metas, leads, desafios e rascunhos salvos no SQLite
- Seleção e upload de vídeos originais até 2 GB (envio integral)
- Editor de textos-modelo por plataforma e contadores de caracteres

## Funcionalidades ainda não integradas
- Transcrição/análise real de vídeo e geração de legendas por IA
- Publicação e agendamento no Instagram, TikTok e YouTube via OAuth/API
- Métricas de redes, CRM integrado com mensagens, automações recorrentes
- Transcodificação FFmpeg, uploads retomáveis, storage de nuvem e múltiplos usuários

O gráfico de crescimento é **ilustrativo**. Os indicadores numéricos são registros reais **locais** do sistema.

## Segurança / produção
Este projeto é um **MVP local**, não um serviço de produção pronto para exposição pública. O servidor escuta apenas em `127.0.0.1`. Para hospedagem pública, adicione HTTPS, proteção contra tentativas de login, CSRF, MFA, auditoria, autorização multiusuário, upload em chunks com antivírus, limites por cliente e armazenamento privado em nuvem. Nunca publique `pgflow.db`, `.env` ou vídeos.
